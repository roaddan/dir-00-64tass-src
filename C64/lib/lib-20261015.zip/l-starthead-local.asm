;--------------------------------------
; nom fichier..: l-bashead-v20exm.asm
; type fichier.: code pour t.m.p.
; auteur.......: daniel lafrance
; version......: 0.0.1
; revision.....: 20261011
;--------------------------------------
; entete pour demarrage basic 2 c64
;--------------------------------------
         *= basstart+1
bcmd1    .word $120c ;adresse de la pro-
                     ; chaine commande.
         .word $0a   ;no. ligne basic.
                     ; 10 dans ce cas.
         .byte $9e   ;jeton pour la
                     ; commande sys.
                     ;Adresse du debut
                     ; du programme en
                     ; decimal/ascii.
         .text format("%5d", bhstart)
         .byte $00   ;fin de cmd basic.
bcmd2    .word $00   ;adresse de la pro-
                     ; chaine commande.
                     ; $00 si aucune.
;--------------------------------------
;pour faciliter la creation de progrm
; la premiere action est de sauter vers
; une routine nommee "main".
;cette methode permet d'utiliser le meme
; entete pour tous les programme.
;la routine "main" doit se terminer par
; un "rts" pour assurer un retour
; adequat a basic.
;--------------------------------------
bhstart   jsr bhscrini
;         jsr bhislib
;         lda #<bhinfo
;         sta $fb
;         lda #>bhinfo
;         sta $fc
;         jsr bhprint
basnold   jsr main
          rts
;--------------------------------------
bhscrini
        .block
        php
        pha
        lda #(128+4)
        sta vic0
bord    lda $900f    ;place la couleur
        and #%00001000
        ora #%00010101    
        sta $900f   
text    lda #$00    ;place la couleur
        sta $0286   ; du texte.
        lda #$93    ;efface l'ecran par
        jsr $ffd2   ; chrout du kernal.
        pla
        plp
        rts
        .bend
;--------------------------------------
;bhislib     
;        .block
;        ldy #$ff
;nextc   iny
;        lda libmark,y
;        beq finish
;        cmp $c000,y
;        beq nextc
;norom   jsr bhldlib
;        rts
;finish  rts      
;libmark .null "libc64"
;        .bend
;--------------------------------------
;bhldlib  
;        .block
;        lda #<bhmsg
;        sta $fb
;        lda #>bhmsg
;        sta $fc
;        jsr bhprint
;doit    lda #7      ;Chrg nfichier len.
;        ldx #<bhname ;Pointe $yyxx->ptr
;        ldy #>bhname ;  nfichier
;        jsr $ffbd   ;setnam
;        lda #$01    ;Chrg lfn dans a
;        ldx #8      ;Periph #8
;        ldy #$01    ;$00:adresse<-yyxx
;                    ;$01:adresse<-fichier
;        jsr $ffba   ;setlfs
;        lda #$00    ;$00:Chrg en memoire
;                    ;$01:Verifier   
;        jsr $ffd5   ;load
;end     rts
;        .bend
;--------------------------------------
;bhprint .block
;        ldy #$00
;nextc   lda ($fb),y
;        beq end
;        iny
;        jsr $ffd2
;        jmp nextc 
;end     rts
;        .bend
;--------------------------------------
;bhmsg   ;.byte $0d,$0d
;        .byte 29,29,29,29,29
;        .byte 29,29
;        .text "chargement/loading:"
;bhname  .null "romc000"
;bhinfo  .byte $0d,$0d
;        .byte 29,29,29,29,29
;        .byte 29,29,29,29,29
;        .text "pour/for information"
;        .byte $0d
;        .byte 29,29,29,29,29
;        .byte 29,29,29,29
;        .text "voir/see:" 
;        .byte 18,32
;        .text "romx000.txt"
;        .byte 32,146
;        .byte $0d,$0d,$0d,$0d,$0d,0
;--------------------------------------
